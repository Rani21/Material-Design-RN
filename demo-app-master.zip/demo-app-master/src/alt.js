import Alt from 'alt';

export default new Alt();